import os
import dotenv
import random
from typing import List, Optional, Tuple, Dict
from pydantic import BaseModel, Field, model_validator, ValidationError


class MazeGenerator:
    """
    A standalone engine for generating, solving, and exporting customizable
    mazes.

    This class orchestrates the complete lifecycle of maze creation:
    1. **Configuration**: strict validation of parameters via Pydantic.
    2. **Generation**: randomized DFS (Depth-First Search) with backtracking.
    3. **Customization**: optional '42' logo embedding and loop creation.
    4. **Solving**: A* algorithm to compute the optimal path.
    5. **Export**: hexadecimal serialization to an output file.

    Usage Example:
        >>> from mazegen import MazeGenerator
        >>> generator = MazeGenerator()
        >>> # Run the full pipeline using a configuration file
        >>> if generator.run(file):
        ...     print("Maze generation successful!")
        ...
        ...     # Access the generated structure (list of lists)
        ...     # Format: [walls_bitmask, visited_status]
        ...     raw_grid = generator._maze
        ...
        ...     # Access the computed solution (N/S/E/W string)
        ...     solution_path = generator.find_way()
        ...     print(f"Solution: {solution_path}")

    Attributes:
        _config (MapConfig): Holds validated parameters (width, height, entry,
                             exit, etc.).
        _maze (List[List[List[int]]]): The internal grid representation.
        _logo_coordinate (List[Tuple[int, int]]): Coordinates reserved for the
                                                  logo pattern.
    """

    class MapConfig(BaseModel):
        """
        Configuration model for maze generation parameters.

        Validates dimensions, ensures entry/exit coordinates are within bounds
        and distinct, and automatically disables the logo if the maze
        dimensions are insufficient.
        """

        width: int = Field(ge=1, description="Maze width (number of cells)")
        height: int = Field(ge=1, description="Maze height (number of cells)")
        entry: tuple[int, int] = Field(description="Entry coordinates (x,y)")
        exit: tuple[int, int] = Field(description="Exit coordinates (x,y)")
        output_file: str = Field(description="Output filename")
        perfect: bool = Field(description="Is the maze perfect?")
        logo: bool = Field(default=True, description="Is the logo printable?")
        seed: Optional[int] = Field(
            default=None, description="Seed for the maze"
        )

        @model_validator(mode="after")
        def check_config(self) -> "MazeGenerator.MapConfig":
            """
            Validate maze configuration after model initialization.

            Checks that:
            - Maze has at least 2 cells
            - Entry and exit coordinates are within bounds
            - Entry and exit are different positions
            - Disables logo for small mazes (width < 5 or height < 7)

            Returns:
                MazeGenerator.MapConfig: Validated config instance.

            Raises:
                ValueError: If dimensions, coordinates, or constraints
                        are invalid.
            """

            entry_x, entry_y = self.entry
            exit_x, exit_y = self.exit
            w, h = self.width, self.height

            if w * h < 2:
                raise ValueError(
                    f"Invalid maze dimensions: {w}x{h}."
                    f" The maze must contain at least 2 cells."
                )

            if not (0 <= entry_x < self.width and 0 <= entry_y < self.height):
                raise ValueError(
                    f"Entry coordinates {self.entry} are out of bounds. "
                    f"Must be between (0,0) and ({w-1},{h-1})."
                )

            if not (0 <= exit_x < self.width and 0 <= exit_y < self.height):
                raise ValueError(
                    f"Exit coordinates {self.exit} are out of bounds. "
                    f"Must be between (0,0) and ({w-1},{h-1})."
                )

            if entry_x == exit_x and entry_y == exit_y:
                raise ValueError(
                    f"Entry and Exit cannot be the same coordinate "
                    f"{self.entry}. The start and end points must be distinct."
                )

            if self.width < 8 or self.height < 6:
                self.logo = False

            return self

    def log_error(self, error: str) -> None:
        """Write the error to 'log_error.txt' without raising an exception."""

        try:
            with open("log_error.txt", "w") as f:
                f.write(error)
        except Exception:
            pass

    def usage(self) -> str:
        """
        Returns the syntax guide and the required keys for the configuration.

        Returns:
            str: The formatted help message.
        """

        help_msg = (
            f"\n{'Required Configuration Format:':<68}"
            f"\n{'='*30:<68}\n\n"
            f"{'Syntax:   KEY=VALUE (One pair per line)':<68}\n"
            f"{'Comments: Lines starting with # are ignored':<68}\n\n"
            f"{'Mandatory Keys & Examples:':<68}\n"
            f"{'-'*70}\n"
            f"{'KEY':<17} | {'DESCRIPTION':<25} | {'EXAMPLE':<20}\n"
            f"{'-'*70}\n"
            f"{'WIDTH (int)':<17} | {'Maze width (cells)':<25} | "
            f"{'WIDTH=20':<20}\n"
            f"{'HEIGHT (int)':<17} | {'Maze height (cells)':<25} | "
            f"{'HEIGHT=15':<20}\n"
            f"{'ENTRY (int, int)':<17} | {'Entry coordinates (x,y)':<25} | "
            f"{'ENTRY=0,0':<20}\n"
            f"{'EXIT (int, int)':<17} | {'Exit coordinates (x,y)':<25} | "
            f"{'EXIT=19,14':<20}\n"
            f"{'OUTPUT_FILE (str)':<17} | {'Output filename':<25} | "
            f"{'OUTPUT_FILE=maze.txt':<20}\n"
            f"{'PERFECT (bool)':<17} | {'Is the maze perfect?':<25} | "
            f"{'PERFECT=True':<20}\n"
            f"{'='*70}\n\n"
            f"{'-'*70}\n"
            f"{f'':<17} | {'OPTIONAL':<25} | {f'':<20}\n"
            f"{'-'*70}\n"
            f"{'SEED (int)':<17} | {'Seed for maze generation':<25} | "
            f"{f'Ex: SEED=45874547':<20}\n"
            f"{'='*70}\n"
        )

        return help_msg

    def load_config(self, file: str) -> bool:
        """
        Load, validate, and instantiate the maze configuration from a file.
        This method temporarily loads environment variables to perform strict
        validation (missing keys, unknown keys, data types) using the Pydantic
        model. Injected variables are cleared from the system environment after
        processing.
        Args:
            file (str): The path to the configuration file.
        Returns:
            bool: True if the configuration is valid and successfully loaded,
            False in case of an error
            (file not found, validation failed, etc.).
        """

        def clear_os(config_read: Dict[str, str | None]) -> None:
            for key in config_read.keys():
                os.environ.pop(key)

        mandatory_keys: List[str] = [
            "WIDTH",
            "HEIGHT",
            "ENTRY",
            "EXIT",
            "OUTPUT_FILE",
            "PERFECT",
        ]
        missing_keys = []

        if not os.path.exists(file):
            self.log_error(f"Configuration Error: File '{file}' not found.")
            return False

        if not dotenv.load_dotenv(file, override=True):
            self.log_error(f"Configuration Error: Failed to read '{file}'.")
            return False

        config_read = dict(dotenv.dotenv_values(file))

        missing_keys = [key for key in mandatory_keys if not os.getenv(key)]
        unknown_keys = [
            key
            for key in config_read
            if key not in mandatory_keys and key != "SEED"
        ]

        if missing_keys:
            error = f"Error config file missing Key: {','.join(missing_keys)}"
            usage = self.usage()
            msg = f"{error:<68}\n" f"{usage}"

            self.log_error(msg)
            clear_os(config_read)
            return False

        if unknown_keys:
            error = f"Error config file unknown Key: {','.join(unknown_keys)}"
            usage = self.usage()
            msg = f"{error:<68}\n" f"{usage}"

            self.log_error(msg)
            clear_os(config_read)
            return False

        try:
            entry_coords = tuple(map(int, str(os.getenv("ENTRY")).split(",")))
            exit_coords = tuple(map(int, str(os.getenv("EXIT")).split(",")))

            self._config = self.MapConfig(
                width=int(str(os.getenv("WIDTH"))),
                height=int(str(os.getenv("HEIGHT"))),
                entry=entry_coords,
                exit=exit_coords,
                output_file=str(os.getenv("OUTPUT_FILE")),
                perfect=os.getenv("PERFECT"),
                seed=os.getenv("SEED"),
            )
            self._maze = [
                [[15, 0] for _ in range(self._config.width)]
                for _ in range(self._config.height)
            ]
            clear_os(config_read)
            return True

        except ValidationError as e:
            errors = e.errors()
            field_name = (
                str(errors[0]["loc"][0]).upper()
                if errors[0]["loc"]
                else "Unknown"
            )
            msg = errors[0]["msg"].replace("Value error, ", "")

            error = (
                f"Validation Error: Invalid configuration for '{field_name}'."
                f"\nReason: {msg}"
            )
            self.log_error(error)
            clear_os(config_read)
            return False

        except Exception as e:
            self.log_error(f"Unexpected Error during config loading: {e}")
            clear_os(config_read)
            return False

    def generate_logo(self) -> bool:
        """
        Generates and embeds the '42' logo pattern at the maze center.

        Validates that the pattern does not overlap with entry or
        exit coordinates before modifying the maze grid.

        Returns:
            bool: True if successful or if the logo is disabled, False if a
            conflict or system error occurs.
        """

        try:
            c = self._config
            m = self._maze
            self._logo_coordinate = []

            if not c.logo:
                return True

            center_x = (c.width // 2) + (c.width % 2)
            center_y = (c.height // 2) + (c.height % 2)

            start_x = center_x - 4
            start_y = center_y - 3

            logo_pixels = []

            for y in range(start_y, start_y + 3):
                logo_pixels.append((y, start_x))
            for y in range(start_y + 2, start_y + 5):
                logo_pixels.append((y, start_x + 2))
            logo_pixels.append((start_y + 2, start_x + 1))

            for y in range(start_y, start_y + 5, 2):
                for x in range(start_x + 4, start_x + 7):
                    logo_pixels.append((y, x))

            logo_pixels.append((start_y + 1, start_x + 6))
            logo_pixels.append((start_y + 3, start_x + 4))

            forbidden_coordinate = {c.entry: "Entry", c.exit: "Exit"}

            for y, x in logo_pixels:
                current_pos = (x, y)

                if current_pos in forbidden_coordinate.keys():
                    point = forbidden_coordinate[current_pos]
                    raise ValueError(
                        f"Configuration Conflict: The {point} point at "
                        f"{current_pos} overlaps with the reserved '42' "
                        f"logo pattern area.\n"
                        f"Resolution: Please move the {point} or disable the "
                        f"logo option."
                    )
                m[y][x][1] = 1
                self._logo_coordinate.append((y, x))
            return True

        except Exception as e:
            self.log_error(
                f"Unexpected system error during logo generation: {e}"
            )
            return False

    def try_break_wall(
        self,
        coordinate: tuple[int, int],
        directions: tuple[int, int],
    ) -> bool:
        """
        Attempts to remove the wall between the current cell and a neighbor.

        Temporarily breaks the wall and validates the local area against
        forbidden patterns (e.g., open rooms or unwanted loops) using bitmasks.
        If a structural violation is detected, the operation is reverted.

        Args:
            coordinate (tuple[int, int]): Current cell coordinates (y, x).
            directions (tuple[int, int]): Direction vector (dy, dx).

        Returns:
            bool: True if the wall was successfully broken, False if reverted
            due to constraints.
        """

        dy, dx = directions
        y, x = coordinate

        m = self._maze
        c = self._config

        reset: List[int] = []

        if dy == -1:
            m[y][x][0] &= ~(1 << 0)
            m[y + dy][x + dx][0] &= ~(1 << 2)
            reset = [1, 4]
        if dx == 1:
            m[y][x][0] &= ~(1 << 1)
            m[y + dy][x + dx][0] &= ~(1 << 3)
            reset = [2, 8]
        if dy == 1:
            m[y][x][0] &= ~(1 << 2)
            m[y + dy][x + dx][0] &= ~(1 << 0)
            reset = [4, 1]
        if dx == -1:
            m[y][x][0] &= ~(1 << 3)
            m[y + dy][x + dx][0] &= ~(1 << 1)
            reset = [8, 2]

        masks = [[6, 6, 4], [6, 6, 4], [2, 2, 0]]

        start_y = max(0, y - 2)
        end_y = min(c.height - 2, y + 2)

        start_x = max(0, x - 2)
        end_x = min(c.width - 2, x + 2)

        for iy in range(start_y, end_y):
            for ix in range(start_x, end_x):

                zone_is_empty = True
                for i_dy in range(3):
                    for i_dx in range(3):
                        if m[iy + i_dy][ix + i_dx][0] & masks[i_dy][i_dx] != 0:
                            zone_is_empty = False
                            break
                    if not zone_is_empty:
                        break

            if zone_is_empty:
                m[y][x][0] |= reset[0]
                m[y + dy][x + dx][0] |= reset[1]
                return False

        return True

    def generate_maze(self) -> bool:
        """
        Generates the maze layout using an iterative Depth-First Search (DFS)
        algorithm.

        Uses a stack-based backtracking approach to ensure a perfect maze
        structure (no loops, fully connected) while respecting constraints
        defined in 'try_break_wall'.

        Returns:
            bool: True if the maze was successfully generated, False if a
            critical error occurred during the process.
        """

        x, y = self._config.entry
        m = self._maze

        width = self._config.width
        height = self._config.height

        directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        m[y][x][1] = 1

        stack = [(y, x)]

        if self._config.seed:
            random.seed(self._config.seed)

        try:
            while stack:
                y, x = stack[-1]

                find_way = False

                random.shuffle(directions)

                for dy, dx in directions:
                    ny, nx = y + dy, x + dx

                    if 0 <= ny < height and 0 <= nx < width:
                        if m[ny][nx][1] == 0:
                            if self.try_break_wall((y, x), (dy, dx)):
                                m[ny][nx][1] = 1
                                stack.append((ny, nx))
                                find_way = True
                                break
                if not find_way:
                    stack.pop()

            return True

        except IndexError as e:
            error = (
                f"Generation Error: Index out of bounds.\n"
                f"Context: Current pos ({y}, {x}), Stack size: {len(stack)}\n"
                f"Traceback: {e}"
            )
            self.log_error(error)
            return False

        except Exception as e:
            error = (
                f"Critical System Error during maze generation.\n"
                f"Last known position: ({y}, {x})\n"
                f"Traceback: {e}"
            )
            self.log_error(error)
            return False

    def add_solutions(self) -> None:
        """
        Post-processes the maze to create loops by opening dead ends.

        Scans the grid for dead-end cells (cells with three walls) and
        selectively removes walls to introduce multiple paths, making
        the maze 'imperfect'. This step is skipped if the configuration
        requires a perfect maze.

        The algorithm targets approximately 50% of identified dead ends to
        maintain a balance between complexity and navigability.
        """

        if self._config.perfect:
            return

        w, h = self._config.width, self._config.height
        m = self._maze

        dead_end = [
            (y, x)
            for y, row in enumerate(m)
            for x, block in enumerate(row)
            if block[0] == 14
            or block[0] == 7
            or block[0] == 13
            or block[0] == 11
            if (y, x) not in self._logo_coordinate
        ]
        i = 0
        for y, x in dead_end:
            if i < int(len(dead_end) / 2):

                if (
                    x + 1 < w
                    and m[y][x][0] == 7
                    and (y, x + 1) not in self._logo_coordinate
                ):
                    if self.try_break_wall((y, x), (0, 1)):
                        i += 1

                elif (
                    y + 1 < h
                    and m[y][x][0] == 14
                    and (y + 1, x) not in self._logo_coordinate
                ):
                    if self.try_break_wall((y, x), (1, 0)):
                        i += 1

                elif (
                    x - 1 >= 0
                    and m[y][x][0] == 13
                    and (y, x - 1) not in self._logo_coordinate
                ):
                    if self.try_break_wall((y, x), (0, -1)):
                        i += 1

                elif (
                    y - 1 >= 0
                    and m[y][x][0] == 11
                    and (y - 1, x) not in self._logo_coordinate
                ):
                    if self.try_break_wall((y, x), (-1, 0)):
                        i += 1

    @staticmethod
    def calculate_f(
        block_passed: int, coordinate: Tuple[int, int], finish: Tuple[int, int]
    ) -> int:
        """
        Computes the A* total cost (F = G + H) using the Manhattan distance
        heuristic.

        Args:
            block_passed (int): Cost from the start node (G).
            coordinate (tuple): Current position (y, x).
            finish (tuple): Target position (y, x).

        Returns:
            int: The calculated F-score.
        """

        y, x = coordinate
        end_y, end_x = finish

        return block_passed + (abs(y - end_y) + abs(x - end_x))

    def find_way(self) -> str:
        """
        Solves the maze using the A* (A-Star) pathfinding algorithm.

        Searches for the shortest path from entry to exit by exploring the
        grid prioritizing nodes with the lowest F-score. Reconstructs the
        path strings (N/S/E/W) by backtracking from the exit.

        Returns:
            str: A string representing the directions (e.g., "NNESW") to solve
            the maze.
            Returns an empty string if no path is found or an error occurs.
        """

        try:
            start_x, start_y = self._config.entry
            end_x, end_y = self._config.exit
            m = self._maze

            start = (start_y, start_x)
            finish = (end_y, end_x)

            open_list = [
                (start, MazeGenerator.calculate_f(0, start, finish), 0)
            ]

            closed_list = set()
            parents = {}
            directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]

            path_found = False
            while open_list:

                open_list.sort(key=lambda x: x[1])

                (y, x), f, g = open_list.pop(0)
                closed_list.add((y, x))

                for i in range(4):

                    if m[y][x][0] & (1 << i) == 0:
                        dy, dx = directions[i]
                        ny, nx = y + dy, x + dx

                        block = (ny, nx)

                        if block == finish:
                            parents[block] = (y, x)
                            path_found = True
                            break

                        if block in closed_list:
                            continue

                        f = MazeGenerator.calculate_f(g + 1, block, finish)

                        open_list.append((block, f, g + 1))
                        parents[block] = (y, x)

                if path_found:
                    break
            if not path_found:
                self.log_error(
                    "Pathfinding Error: No valid path connects entry to exit."
                )
                return ""

            curr = (end_y, end_x)
            way = ""
            while curr != (start_y, start_x):
                dy, dx = curr[0] - parents[curr][0], curr[1] - parents[curr][1]
                if dy == -1:
                    way += "N"
                if dx == 1:
                    way += "E"
                if dy == 1:
                    way += "S"
                if dx == -1:
                    way += "W"
                curr = parents[curr]

            return way[::-1]

        except Exception as e:
            self.log_error(
                f"Critical Error in pathfinding algorithm.\n" f"Traceback: {e}"
            )
            return ""

    def run(self, file: str) -> bool:
        """
        Orchestrates the complete maze generation workflow.

        This main execution method performs the following sequential steps:
        1. Loads and validates the configuration from the provided file.
        2. Generates the '42' logo pattern (if enabled).
        3. Generates the random maze structure.
        4. Post-processes the maze to add loops (unless 'perfect' mode is on).
        5. Formats the grid and solution path into a string.
        6. Writes the final result to the specified output file.

        Args:
            config_file (str): Path to the configuration file.

        Returns:
            bool: True if the entire pipeline succeeds and the file is saved.
                  False if any step (loading, generation, or I/O) fails.
        """

        if os.path.exists("log_error.txt"):
            os.remove("log_error.txt")

        if (
            self.load_config(file)
            and self.generate_logo()
            and self.generate_maze()
        ):
            self.add_solutions()
            try:
                output = ""
                start_x, start_y = self._config.entry
                end_x, end_y = self._config.exit

                for row in self._maze:
                    for block in row:
                        output += f"{block[0]:X}"
                    output += "\n"
                output += f"\n{start_x},{start_y}\n"
                output += f"{end_x},{end_y}\n"
                output += self.find_way()

                with open(self._config.output_file, "w") as f:
                    f.write(output)
                    return True

            except PermissionError:
                error = (
                    f"File Error: Permission denied.\n"
                    f"Context: Cannot write to '{self._config.output_file}'. "
                    f"Check file permissions."
                )
                self.log_error(error)
                return False

            except OSError as e:
                self.log_error(
                    f"System Error: Failed to save file.\nTraceback: {e}"
                )
                return False

            except Exception as e:
                self.log_error(
                    f"Unexpected error during output file generation: {e}"
                )
                return False
        else:
            return False
